﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LibraryManageSyst
{
    public partial class Form1 : Form
    {
        string userName = "";
        string password = "";


        public Form1()
        {
            InitializeComponent();
        }

        SqlConnection connection = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"|DataDirectory|\\Database.mdf\";Integrated Security=True");
        SqlCommand cmd;
        SqlDataReader DataRead;

        private string getUserName()
        {
            //fetches data from the database
            connection.Open();
            string syntax = "SELECT Value FROM systemTable WHERE Property = 'Username' ";
            cmd = new SqlCommand(syntax, connection);
            DataRead = cmd.ExecuteReader();
            DataRead.Read();
            string temp = DataRead[0].ToString();
            connection.Close();
            return temp;

        }

        private string getPassword()
        {
            //fetches data from the database
            connection.Open();
            string query = "SELECT Value FROM systemTable WHERE Property = 'Password' ";
            cmd = new SqlCommand(query, connection);
            DataRead = cmd.ExecuteReader();
            DataRead.Read();
            string temp = DataRead[0].ToString();
            connection.Close();
            return temp;

        }



        private void button1_Click(object sender, EventArgs e)
        {
            
            userName = getUserName();
            password = getPassword();
            string name = textBox1.Text;
            string pass = textBox2.Text;

            if(name.Equals(userName) && pass.Equals(password))
            {
                AppUI appUI = new AppUI();
                this.Hide();
                appUI.Show();
            }
            else
            {
                MessageBox.Show("Wrong name or password!");
            }

        }
    }
}
