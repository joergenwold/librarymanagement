﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryManageSyst
{
    public partial class addNew : Form
    {
        public int accNo;
        public int dId;
        public string name = "";
        public string publisher = "";
        public string isbn = "";
        public string author = "";


        public addNew()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            if(textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && textBox4.Text != "" && textBox5.Text != "")
            {
                name = textBox1.Text;
                publisher = textBox2.Text;
                isbn = textBox3.Text;
                author = textBox4.Text;
                accNo = Convert.ToInt32(textBox5.Text);
                dId = Convert.ToInt32(comboBox1.Text);
            }
            this.Close();
        }

        private void label11_Click(object sender, EventArgs e)
        {

        }
    }
}
