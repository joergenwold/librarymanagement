﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LibraryManageSyst
{ 
    public partial class BookUsercontrol : UserControl
    {
        private static BookUsercontrol _instance;

        public static BookUsercontrol theInstance
        {
            get
            {
                if(_instance == null)
                {
                    _instance = new BookUsercontrol();
                }
                return _instance;
            }
        }

        public BookUsercontrol()
        {
            InitializeComponent();
        }


        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"|DataDirectory|\\Database.mdf\";Integrated Security=True");


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            addNew addNew = new addNew();
           
            addNew.ShowDialog();
            if (addNew.DialogResult == DialogResult.OK)
            {
                
                SqlCommand cmd = new SqlCommand("BooksAdd_SP", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@accNo", addNew.accNo);
                cmd.Parameters.AddWithValue("@isbn", addNew.isbn);
                cmd.Parameters.AddWithValue("@Name", addNew.name);
                cmd.Parameters.AddWithValue("@Author", addNew.author);
                cmd.Parameters.AddWithValue("@Publisher", addNew.publisher);
                cmd.Parameters.AddWithValue("@dId", addNew.dId);

                con.Open();

                try
                {
                    cmd.ExecuteNonQuery();

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Invalid Sql operation" + ex);
                   
                }
                con.Close();

                refreshTheDataGrid();
            }
           
        }

        public void refreshTheDataGrid()
        {
            try
            {
                SqlCommand cmd = new SqlCommand("ShowAllBooks_SP", con);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlDataAdapter dataAdapt = new SqlDataAdapter(cmd);
                DataSet dataSet = new DataSet();
                dataAdapt.Fill(dataSet);

                con.Open();
                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Invalid sql operation" + ex);
                }
                con.Close();

                dataGridView1.DataSource = dataSet.Tables[0];
                this.dataGridView1.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
                this.dataGridView1.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                this.dataGridView1.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                this.dataGridView1.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                this.dataGridView1.Columns[4].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                this.dataGridView1.Columns[5].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                this.dataGridView1.Columns[6].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                this.dataGridView1.Columns[7].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                this.dataGridView1.Columns[8].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;


            }
            catch (Exception ex)
            {
                MessageBox.Show("" + ex);
                
            }
        }

        private void BookUsercontrol_Load(object sender, EventArgs e)
        {
            //refreshTheDataGrid();
        }
    }
}
